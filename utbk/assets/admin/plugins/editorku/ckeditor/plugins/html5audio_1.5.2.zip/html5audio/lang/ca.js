CKEDITOR.plugins.setLang( 'html5audio', 'ca', {
    button: "Insereix un àudio HTML5",
    title: "Àudio HTML5",
    infoLabel: "Informació de l'àudio",
    urlMissing: "Falta l'URL d'origen d'àudio.",
    audioProperties: "Propietats de l'àudio",
    upload: "Pujar",
    btnUpload: "Envia-lo al servidor",
    advanced: "Avançat",
    autoplay: "Reproducció automàtica?",
    allowdownload: "Permet la descàrrega?",
    advisorytitle: 'Advisory title',
    yes: "Sí",
    no: "No"
} );
