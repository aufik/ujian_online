CKEDITOR.plugins.setLang( 'html5audio', 'de', {
    button: 'HTML5 Audio einfügen',
    title: 'HTML5 Audio',
    infoLabel: 'Audio Infos',
    urlMissing: 'Sie haben keine URL zur Audio-Datei angegeben.',
    audioProperties: 'Audio-Einstellungen',
    upload: 'Hochladen',
    btnUpload: 'Zum Server senden',
    advanced: 'Erweitert',
    autoplay: 'Autoplay?',
    allowdownload: 'Download zulassen?',
    advisorytitle: 'Titel Beschreibung',
    yes: 'Ja',
    no: 'Nein'
} );
